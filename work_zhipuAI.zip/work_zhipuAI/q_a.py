import random

from wudao.api_request import executeEngineV2, getToken, queryTaskResult


def qa_system(question):
    # 接口API KEY
    API_KEY = "40dd4a6789914c7e8892955021160350"
    # 公钥
    PUBLIC_KEY = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAJeTnGgmK/3OEtrziEio5AXpTaIdJwjdGkSKixGHFfrWZB6jmJxRJF4MOJQiKODBYXVyrXKbghoIKWayEY9Z8V8CAwEAAQ=="
    # 能力类型
    ability_type = "question_answer"
    # 引擎类型
    engine_type = "txl-general-engine-v1"
    # 请求参数样例
    requestTaskNo = random.randint(100, 100000000)
    data = {
        "topP": 1,
        "topK": 3,
        "temperature": 1,
        "presencePenalty": 1,
        "frequencyPenalty": 1,
        "generatedLength": 256,
        # "prompt": "猪八戒是谁？",
        "prompt": question,
        "promptDesc": "",
        "requestTaskNo": requestTaskNo
    }

    '''
      注意这里仅为了简化编码每一次请求都去获取token， 线上环境token有过期时间， 客户端可自行缓存，过期后重新获取。
    '''
    token_result = getToken(API_KEY, PUBLIC_KEY)

    if token_result and token_result["code"] == 200:
        token = token_result["data"]
        resp = executeEngineV2(ability_type, engine_type, token, data)
        print(resp, '\n')

        resp2 = queryTaskResult(token, resp['data']['taskOrderNo'])
        while (resp2['data']['taskStatus'] == 'PROCESSING'):
            resp2 = queryTaskResult(token, resp['data']['taskOrderNo'])
        print(resp2, '\n')

        ans = resp2['data']['outputText']
        print(ans, '\n')
        return ans
    else:
        print("获取token失败，请检查 API_KEY 和 PUBLIC_KEY")


if __name__ == '__main__':
    qa_system('')
