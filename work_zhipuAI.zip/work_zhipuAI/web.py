from flask import Flask, render_template, request
import q_a

app = Flask(__name__)


@app.route("/question_answer")
def index():
    ans = ''
    question = request.args.get('question')
    if question is not None:
        print(question)
        ans = q_a.qa_system(question)
        return render_template("index2.html", answer=ans, question=question)
    return render_template("index2.html", answer=ans, question=question)


if __name__ == '__main__':
    app.run()
